/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algorithms.vf2;

import DiGraph.DiGraph;

/**
 *
 * @author user
 */
public class VF2 {
    DiGraph A;
    DiGraph B;

    public VF2(DiGraph A, DiGraph B) {
        this.A = A;
        this.B = B;
    }
    
}
